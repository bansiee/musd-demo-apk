package com.example.musd_med_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
