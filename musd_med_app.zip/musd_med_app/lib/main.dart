import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Musd Med',
      theme: ThemeData(
        // ===== COLOR SCHEME =====
        colorScheme: ColorScheme.light(
          primary: const Color(0xFF4EAC50), // Green (rgb(78,172,80))
          secondary: const Color(0xFF262247), // Dark purple
          surface: Colors.white, // Card backgrounds
          background: Colors.white, // Page background
        ),

        // ===== TEXT THEMING =====
        textTheme: const TextTheme(
          headlineLarge: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Color(0xFF262247), // Dark purple for headings
          ),
          bodyLarge: TextStyle(
            fontSize: 16,
            color: Colors.black87,
          ),
          labelLarge: TextStyle(
            fontSize: 18,
            color: Colors.white, // White text for buttons
            fontWeight: FontWeight.bold,
          ),
        ),

        // ===== INPUT FIELD STYLING =====
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          filled: true,
          fillColor: Colors.grey.shade50,
        ),

        // ===== BUTTON THEMING =====
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF4EAC50), // Green buttons
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),

        // ===== CARD THEMING =====
        cardTheme: CardTheme(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          margin: const EdgeInsets.all(8),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
