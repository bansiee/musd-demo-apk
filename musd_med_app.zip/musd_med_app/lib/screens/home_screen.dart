import 'package:flutter/material.dart';
import 'appointment_form.dart'; // Hospital form
import 'abroad_form.dart'; // International form
import 'my_requests_screen.dart'; // Must match the exact filename

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Musd Med'),
        actions: [
          IconButton(
            icon: const Icon(Icons.language),
            onPressed: () {}, // We'll implement later
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // 1. Hospital Appointment Button
            Card(
              child: ListTile(
                leading: const Icon(Icons.local_hospital, size: 40),
                title: const Text('Hospital Appointment (Local)'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const AppointmentForm(),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 16),

            // 2. International Referral Button
            Card(
              child: ListTile(
                leading: const Icon(Icons.airplanemode_active, size: 40),
                title: const Text('International Referral + Visa Help'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const AbroadForm(),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 16),

            // 3. Support Button (Optional)
            Card(
              child: ListTile(
                leading: const Icon(Icons.support, size: 40),
                title: const Text('Contact Support'),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Support options coming soon!'),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      // Bottom Navigation Bar
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'My Requests',
          ),
        ],
        onTap: (index) {
          if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    const MyRequestsScreen(), // Must match class name
              ),
            );
            ;
          }
        },
      ),
    );
  }
}
