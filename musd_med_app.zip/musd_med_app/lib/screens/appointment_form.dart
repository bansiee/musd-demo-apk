import 'package:flutter/material.dart';
import '../models/appointment.dart';
import 'confirmation_screen.dart';

class AppointmentForm extends StatefulWidget {
  const AppointmentForm({super.key});

  @override
  State<AppointmentForm> createState() => _AppointmentFormState();
}

class _AppointmentFormState extends State<AppointmentForm> {
  final _formKey = GlobalKey<FormState>();
  String? _gender = 'Male';
  DateTime? _selectedDate;
  String? _phoneCode = '+251'; // Default to Ethiopia
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  // East African country codes
  final List<Map<String, String>> countryCodes = [
    {'code': '+251', 'name': 'Ethiopia'},
    {'code': '+252', 'name': 'Somalia'},
    {'code': '+254', 'name': 'Kenya'},
    {'code': '+255', 'name': 'Tanzania'},
    {'code': '+256', 'name': 'Uganda'},
  ];

  @override
  void dispose() {
    _ageController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hospital Appointment')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Full Name Field
            TextFormField(
              decoration: const InputDecoration(
                labelText: 'Full Name',
                hintText: 'Enter your full name',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your name';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),

            // Phone Number with Country Code
            Row(
              children: [
                // Country Code Dropdown
                DropdownButton<String>(
                  value: _phoneCode,
                  items: countryCodes.map((country) {
                    return DropdownMenuItem(
                      value: country['code'],
                      child: Text('${country['code']} (${country['name']})'),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _phoneCode = value;
                    });
                  },
                ),
                const SizedBox(width: 10),
                // Phone Number Field
                Expanded(
                  child: TextFormField(
                    controller: _phoneController,
                    decoration: const InputDecoration(
                      labelText: 'Phone Number',
                      hintText: '912345678',
                    ),
                    keyboardType: TextInputType.phone,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter phone number';
                      }
                      if (!RegExp(r'^[0-9]{9}$').hasMatch(value)) {
                        return 'Enter 9-digit number (e.g. 912345678)';
                      }
                      return null;
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Age Field
            TextFormField(
              controller: _ageController,
              decoration: const InputDecoration(
                labelText: 'Age',
                hintText: 'Enter your age',
              ),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your age';
                }
                final age = int.tryParse(value);
                if (age == null || age < 1 || age > 120) {
                  return 'Enter valid age (1-120)';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),

            // Gender Dropdown
            DropdownButtonFormField<String>(
              value: _gender,
              decoration: const InputDecoration(
                labelText: 'Gender',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: 'Male', child: Text('Male')),
                DropdownMenuItem(value: 'Female', child: Text('Female')),
              ],
              onChanged: (value) {
                setState(() {
                  _gender = value;
                });
              },
              validator: (value) =>
                  value == null ? 'Please select gender' : null,
            ),
            const SizedBox(height: 16),

            // Date Picker
            ListTile(
              title: Text(
                _selectedDate == null
                    ? 'Select Preferred Date'
                    : 'Selected: ${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}',
              ),
              trailing: const Icon(Icons.calendar_today),
              shape: RoundedRectangleBorder(
                side: const BorderSide(color: Colors.grey),
                borderRadius: BorderRadius.circular(4),
              ),
              onTap: () async {
                final date = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 365)),
                  helpText: 'Select appointment date',
                  cancelText: 'Cancel',
                  confirmText: 'Select',
                  errorFormatText: 'Invalid date',
                  errorInvalidText: 'Date must be in the future',
                );
                if (date != null) {
                  setState(() {
                    _selectedDate = date;
                  });
                }
              },
            ),
            if (_selectedDate == null)
              const Padding(
                padding: EdgeInsets.only(left: 16, top: 4),
                child: Text(
                  'Please select a date',
                  style: TextStyle(color: Colors.red, fontSize: 12),
                ),
              ),
            const SizedBox(height: 24),

            // Submit Button
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate() &&
                    _selectedDate != null) {
                  // Form is valid - proceed to confirmation
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ConfirmationScreen(),
                    ),
                  );
                } else if (_selectedDate == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Please select a date'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: const Text('Submit Request'),
            ),
          ],
        ),
      ),
    );
  }
}
