import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'confirmation_screen.dart';

class AbroadForm extends StatefulWidget {
  const AbroadForm({super.key});

  @override
  State<AbroadForm> createState() => _AbroadFormState();
}

class _AbroadFormState extends State<AbroadForm> {
  final _formKey = GlobalKey<FormState>();
  String? _gender = 'Male';
  DateTime? _selectedDate;
  String? _phoneCode = '+251';
  String? _destinationCountry;
  dynamic _passportFile;
  bool _isUploading = false;
  String? _passportDownloadUrl;

  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _passportNumberController =
      TextEditingController();

  final List<Map<String, String>> countryCodes = [
    {'code': '+251', 'name': 'Ethiopia'},
    {'code': '+252', 'name': 'Somalia'},
    {'code': '+254', 'name': 'Kenya'},
    {'code': '+255', 'name': 'Tanzania'},
    {'code': '+256', 'name': 'Uganda'},
  ];

  final List<String> destinationCountries = [
    'Turkey',
    'India',
    'United Arab Emirates',
    'Germany',
    'United Kingdom',
    'United States',
    'Thailand',
    'Malaysia'
  ];

  Future<void> _uploadPassport() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['jpg', 'jpeg', 'png', 'pdf'],
      );

      if (result != null) {
        setState(() {
          _passportFile = result;
          _isUploading = true;
        });

        final storageRef = FirebaseStorage.instance
            .ref()
            .child('passports/${DateTime.now().millisecondsSinceEpoch}');

        await storageRef.putData(_passportFile.files.first.bytes!);
        _passportDownloadUrl = await storageRef.getDownloadURL();

        setState(() => _isUploading = false);
      }
    } catch (e) {
      setState(() => _isUploading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Upload failed: ${e.toString()}')),
      );
    }
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _ageController.dispose();
    _phoneController.dispose();
    _passportNumberController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('International Referral')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _fullNameController,
              decoration: const InputDecoration(
                labelText: 'Full Name',
                hintText: 'Enter your full name as in passport',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your name';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                DropdownButton<String>(
                  value: _phoneCode,
                  items: countryCodes.map((country) {
                    return DropdownMenuItem(
                      value: country['code'],
                      child: Text('${country['code']} (${country['name']})'),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _phoneCode = value;
                    });
                  },
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextFormField(
                    controller: _phoneController,
                    decoration: const InputDecoration(
                      labelText: 'Phone Number',
                      hintText: '912345678',
                    ),
                    keyboardType: TextInputType.phone,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter phone number';
                      }
                      if (!RegExp(r'^[0-9]{9}$').hasMatch(value)) {
                        return 'Enter 9-digit number (e.g. 912345678)';
                      }
                      return null;
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _ageController,
              decoration: const InputDecoration(
                labelText: 'Age',
                hintText: 'Enter your age',
              ),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your age';
                }
                final age = int.tryParse(value);
                if (age == null || age < 1 || age > 120) {
                  return 'Enter valid age (1-120)';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _gender,
              decoration: const InputDecoration(
                labelText: 'Gender',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: 'Male', child: Text('Male')),
                DropdownMenuItem(value: 'Female', child: Text('Female')),
              ],
              onChanged: (value) {
                setState(() {
                  _gender = value;
                });
              },
              validator: (value) =>
                  value == null ? 'Please select gender' : null,
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _destinationCountry,
              decoration: const InputDecoration(
                labelText: 'Destination Country',
                border: OutlineInputBorder(),
              ),
              items: destinationCountries.map((country) {
                return DropdownMenuItem(
                  value: country,
                  child: Text(country),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _destinationCountry = value;
                });
              },
              validator: (value) =>
                  value == null ? 'Please select destination country' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _passportNumberController,
              decoration: const InputDecoration(
                labelText: 'Passport Number',
                hintText: 'A12345678',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter passport number';
                }
                if (!RegExp(r'^[A-Za-z][0-9]{7,8}$').hasMatch(value)) {
                  return 'Enter valid passport number (e.g. A12345678)';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _isUploading ? null : _uploadPassport,
              icon: _isUploading
                  ? const CircularProgressIndicator()
                  : const Icon(Icons.upload),
              label: Text(
                _passportFile == null
                    ? 'Upload Passport Copy (PDF/JPG)'
                    : 'Uploaded: ${_passportFile.files.first.name}',
              ),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            if (_passportFile == null)
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text(
                  'Required: PDF or clear photo',
                  style: TextStyle(color: Colors.red, fontSize: 12),
                ),
              ),
            const SizedBox(height: 16),
            ListTile(
              title: Text(
                _selectedDate == null
                    ? 'Select Preferred Travel Date'
                    : 'Selected: ${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}',
              ),
              trailing: const Icon(Icons.calendar_today),
              shape: RoundedRectangleBorder(
                side: const BorderSide(color: Colors.grey),
                borderRadius: BorderRadius.circular(4),
              ),
              onTap: () async {
                final date = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 365)),
                );
                if (date != null) {
                  setState(() {
                    _selectedDate = date;
                  });
                }
              },
            ),
            if (_selectedDate == null)
              const Padding(
                padding: EdgeInsets.only(left: 16, top: 4),
                child: Text(
                  'Please select a date',
                  style: TextStyle(color: Colors.red, fontSize: 12),
                ),
              ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate() &&
                    _selectedDate != null &&
                    _passportFile != null) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ConfirmationScreen(),
                    ),
                  );
                } else if (_passportFile == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Please upload passport copy'),
                      backgroundColor: Colors.red,
                    ),
                  );
                } else if (_selectedDate == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Please select travel date'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: const Text('Submit Request'),
            ),
          ],
        ),
      ),
    );
  }
}
