import 'package:flutter/material.dart';

class MyRequestsScreen extends StatelessWidget {
  // Must be EXACTLY this name
  const MyRequestsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Requests')),
      body: ListView(
        children: const [
          ListTile(
            leading: Icon(Icons.local_hospital),
            title: Text('Hospital Appointment'),
            subtitle: Text('Status: Pending'),
          ),
          // ... rest of your code
        ],
      ),
    );
  }
}
