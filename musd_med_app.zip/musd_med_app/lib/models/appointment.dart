class Appointment {
  final String fullName;
  final String phone;
  final String age;
  final String gender;
  final DateTime date;

  Appointment({
    required this.fullName,
    required this.phone,
    required this.age,
    required this.gender,
    required this.date,
  });
}
