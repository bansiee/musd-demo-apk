// This defines how request data is stored
class MedicalRequest {
  final String id;
  final String type; // 'hospital' or 'international'
  final String patientName;
  final String status; // 'Pending', 'Completed'
  final DateTime date;

  MedicalRequest({
    required this.id,
    required this.type,
    required this.patientName,
    required this.status,
    required this.date,
  });
}
